package com.sunsoft.QuestionAnswerAdmin.Repository;


import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.sunsoft.QuestionAnswerAdmin.Entity.QuestionAnswerAdmin;


@Repository("/questionanswerRepository")
public interface QuestionAnswerAdminRepository extends JpaRepository<QuestionAnswerAdmin, Integer>{

}
