package com.sunsoft.QuestionAnswerAdmin.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunsoft.QuestionAnswerAdmin.Entity.QuestionAnswerAdmin;
import com.sunsoft.QuestionAnswerAdmin.Exception.ResourceNotFoundException;
import com.sunsoft.QuestionAnswerAdmin.Service.IQuestionAnswerAdminService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/subject")
public class  QuesAnswerAdminController{
	@Autowired
	private IQuestionAnswerAdminService questionadminService;

	@GetMapping("/question")
	public List<QuestionAnswerAdmin> getAllEmployees() {
		return questionadminService.getQuestion();
	}

	@GetMapping("/question/{sno}")
	public ResponseEntity<QuestionAnswerAdmin> getQuestionById(@PathVariable(value = "sno") int sno)
			throws ResourceNotFoundException {
		QuestionAnswerAdmin question = questionadminService.getQuestionBySno(sno)
				.orElseThrow(() -> new ResourceNotFoundException("Question not found for this sno :: " + sno));
		return ResponseEntity.ok().body(question);
	}

	@PostMapping(path="/question",consumes="application/json",produces="application/json")
	public QuestionAnswerAdmin createQuestion(@Valid @RequestBody QuestionAnswerAdmin question) {
		return questionadminService.save(question);
	}

	@PutMapping("/question/{sno}")
	public ResponseEntity<QuestionAnswerAdmin> updateQuestion(@PathVariable(value = "sno") int sno,
			@Valid @RequestBody QuestionAnswerAdmin questionDetails) throws ResourceNotFoundException {
		QuestionAnswerAdmin question = questionadminService.getQuestionBySno(sno)
				.orElseThrow(() -> new ResourceNotFoundException("Question not found for this sno :: " + sno));

		question.setQuestionvalue(questionDetails.getQuestionvalue());
		question.setQuestionmarks(questionDetails.getQuestionmarks());
		question.setQuestiondomain(questionDetails.getQuestiondomain());
		question.setCorrectoption(questionDetails.getCorrectoption());
		question.setOption1(questionDetails.getOption1());
		question.setOption2(questionDetails.getOption2());
		question.setOption3(questionDetails.getOption3());
		question.setOption4(questionDetails.getOption4());
		final QuestionAnswerAdmin updatedQuestion = questionadminService.save(question);
		return ResponseEntity.ok(updatedQuestion);
	}

	@DeleteMapping("/question/{sno}")
	public Optional<QuestionAnswerAdmin> deleteQuestion(@PathVariable(value = "sno") int sno) throws ResourceNotFoundException
	{
		return questionadminService.deleteQuestion(sno);
	}
	
}
