package com.sunsoft.QuestionAnswerAdmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuestionAnswerAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuestionAnswerAdminApplication.class, args);
	}

}
