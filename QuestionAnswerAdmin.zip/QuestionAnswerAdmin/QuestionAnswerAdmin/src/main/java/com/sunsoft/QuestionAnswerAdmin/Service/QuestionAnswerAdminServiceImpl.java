package com.sunsoft.QuestionAnswerAdmin.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunsoft.QuestionAnswerAdmin.Entity.QuestionAnswerAdmin;
import com.sunsoft.QuestionAnswerAdmin.Exception.ResourceNotFoundException;
import com.sunsoft.QuestionAnswerAdmin.Repository.QuestionAnswerAdminRepository;

@Service
public class QuestionAnswerAdminServiceImpl implements IQuestionAnswerAdminService {
@Autowired
QuestionAnswerAdminRepository questionanswerRepository;
	@Override
	public List<QuestionAnswerAdmin> getQuestion() {
		List<QuestionAnswerAdmin> question = new ArrayList<QuestionAnswerAdmin>();  
		questionanswerRepository.findAll().forEach(question1 -> question.add(question1));  
		return question;  
		
	}

	@Override
	public QuestionAnswerAdmin save(QuestionAnswerAdmin question) {
		return questionanswerRepository.save(question); 
	}

	@Override
	public Optional<QuestionAnswerAdmin> getQuestionBySno(int sno) {
		return questionanswerRepository.findById(sno);
		
	}

	@Override
	public Optional<QuestionAnswerAdmin> deleteQuestion(int sno) throws ResourceNotFoundException{
	Optional<QuestionAnswerAdmin> question =questionanswerRepository.findById(sno);
	if(question!=null)
	{
		questionanswerRepository.deleteById(sno);
		return question;
		
	}else
	{
		throw new ResourceNotFoundException("No question exists of thid Sno");

}
}
}