package com.sunsoft.QuestionAnswerAdmin.Service;

import java.util.List;
import java.util.Optional;

import com.sunsoft.QuestionAnswerAdmin.Entity.QuestionAnswerAdmin;
import com.sunsoft.QuestionAnswerAdmin.Exception.ResourceNotFoundException;



public interface IQuestionAnswerAdminService {
	public List<QuestionAnswerAdmin> getQuestion();
	public QuestionAnswerAdmin save(QuestionAnswerAdmin question);
	public Optional<QuestionAnswerAdmin> getQuestionBySno(int sno);
	public Optional<QuestionAnswerAdmin> deleteQuestion(int sno) throws ResourceNotFoundException;


}
