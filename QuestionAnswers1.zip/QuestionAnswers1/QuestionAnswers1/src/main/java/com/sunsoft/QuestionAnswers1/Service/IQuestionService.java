package com.sunsoft.QuestionAnswers1.Service;

import java.util.List;
import java.util.Optional;

import com.sunsoft.QuestionAnswers1.Entity.QuestionandAnswer;



public interface IQuestionService{
	
public List<QuestionandAnswer> getQuestion();
public QuestionandAnswer save(QuestionandAnswer question);
public Optional<QuestionandAnswer> getQuestionBySno(String Sno);



}