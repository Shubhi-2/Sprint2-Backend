package com.sunsoft.QuestionAnswers1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuestionAnswers1Application {

	public static void main(String[] args) {
		SpringApplication.run(QuestionAnswers1Application.class, args);
	}

}
