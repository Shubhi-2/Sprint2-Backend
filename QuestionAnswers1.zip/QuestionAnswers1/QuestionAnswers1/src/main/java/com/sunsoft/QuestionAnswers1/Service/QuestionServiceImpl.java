package com.sunsoft.QuestionAnswers1.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.sunsoft.QuestionAnswers1.Entity.QuestionandAnswer;
import com.sunsoft.QuestionAnswers1.Repository.QuestionRepository;

@Service
public class QuestionServiceImpl  implements IQuestionService{
@Autowired 
QuestionRepository questionRepository;
	@Override
	public List<QuestionandAnswer> getQuestion() {
		
		List<QuestionandAnswer> question = new ArrayList<QuestionandAnswer>();  
		questionRepository.findAll().forEach(question1 -> question.add(question1));  
		return question;  
		
	}

	@Override
	public QuestionandAnswer save(QuestionandAnswer question) {
		return questionRepository.save(question);  
		
	}

	@Override
	public Optional<QuestionandAnswer> getQuestionBySno(String Sno) {
		
		return questionRepository.findById(Sno);
	}

	
		
	}

	
